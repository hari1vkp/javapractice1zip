import java.util.Random;
public class randon {
    public static void main(String[] args) {
        Random ran = new Random();
        int a=0;
        for (int i = 0; a!=5; i=i+1){
            a = ran.nextInt();
            System.out.println(a);
        }
    }
}