import java.util.Scanner;
public class Apple
{

    void total(int a,int b){
        System.out.println("total cost is  "+(a*b)+" rs");
    }

    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("how many apples you need");
        int no_apples=scan.nextInt();
        int price=30;
       Apple h=new Apple();
       h.total(no_apples,price);

    }
}
