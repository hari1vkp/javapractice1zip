import java.util.Scanner;
class Searh{
    public  static  int btree(int[]arr,int n)
    {
        int left=0;
        int right=arr.length-1;
        while (left<=right){
            int mid=left+(right-left)/2;
            if(arr[mid]==n){
                return mid;
            } else if (n>arr[mid])
            {
                left=mid+1;
            }
            else{
                right=mid-1;
            }

        }
        return -1;

    }

}
public class Bsearch {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        int arr[]={4,6,7,9,34,67};
        System.out.println("enter the target");
        int a= scan.nextInt();
        int res=Searh.btree(arr,a)+1;
        if(res==-1){
            System.out.println("not found");
        }
        else {
            System.out.println("the order of given value is "+res);
        }

    }
}