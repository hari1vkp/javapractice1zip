import java.util.Scanner;
public class Mark {
    public static void main(String args[]){
        System.out.println("enna thambi mark:");
        Scanner mark=new Scanner(System.in);
        int a=mark.nextInt();
        mark.close();
        if (a>=50&&a<80)
        {
            System.out.println("candy");
        } else if (a>=80&&a<90)
        {
            System.out.println("phone");
        } else if (a>=90)
        {
            System.out.println("laptop");
        }else {
            System.out.println("nothing");
        }

    }
}
