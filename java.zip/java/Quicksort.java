public class Quicksort {

    public static void main(String[] args) {
        int[] array = {7, 9, 5, 3, 4, 65};
        System.out.println("Before:");
        printArray(array);
        quicksort(array, 0, array.length - 1);
        System.out.println("After:");
        printArray(array);
    }

    public static void quicksort(int[] array, int li, int hi) {
        if (li >= hi) {
            return;
        }
        int pivot = array[hi];
        int lp = li;
        int rp = hi - 1;

        while (lp <= rp) {
            while (lp <= rp && array[lp] < pivot) {
                lp++;
            }
            while (lp <= rp && array[rp] > pivot) {
                rp--;
            }
            if (lp <= rp) {
                swap(array, lp, rp);
                lp++;
                rp--;
            }
        }

        swap(array, lp, hi);
        quicksort(array, li, lp - 1);
        quicksort(array, lp + 1, hi);
    }

    public static void swap(int[] array, int in1, int ind2) {
        int temp = array[in1];
        array[in1] = array[ind2];
        array[ind2] = temp;
    }

    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }
}
