public class Add_return {
    int sum(int a,int b)
    {
        int c=a+b;
        return c;
    }

    public static void main(String[] args) {
        int an=7;
        int bn=7;
        Add_return h=new Add_return();
        int har=h.sum(an,bn);
        System.out.println(har);
    }
}
