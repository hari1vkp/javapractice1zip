import java.util.Scanner;
public class Find {
    String oddeven(int a) {
        String ha=(a%2==1?"odd":"even");
        return ha;
      /*  if (a%2==1){
            System.out.println("odd");
        }
        else {
            System.out.println("even");
        }*/
    }

    public static void main(String[] args)
        {
        System.out.println("give number");
        Scanner scan=new Scanner(System.in);
        int a=scan.nextInt();
        Find ove=new Find();
        String hai= ove.oddeven(a);
        System.out.println(hai);

    }
}
