public class Test {
 public static void main(String[] args) {
    int array[]={45,98,76,56,34,25};
    System.out.println("before");
    arraprint(array);
    quicksort(array,0,array.length-1);
    System.out.println("after");
    arraprint(array);
 }
 public static void  arraprint(int arr[])
    {
    for(int i=0;i<arr.length;i++){
        System.out.println(arr[i]);
    }
    }
    public static void quicksort(int[]array,int low, int high){
        if (low>high) {
            return;
        }
        int pivot=array[high];
        int lp=low;
        int rp=high-1;
        while (lp<=rp)
         {
            while (lp<=rp && array[lp]<pivot)
             {
                lp++;
       
            }
            while (lp<=rp && array[rp]>pivot)
             {
                rp--;
            }
            if (lp<=rp)
             {
                swap(array, lp, rp);
                lp++;
                rp--;
            }
            swap(array, lp, high);
            quicksort(array, low,lp-1 );
            quicksort(array, lp+1, high);
           

        }
    }
    public static void swap(int[]array,int a,int b){
        int temp=array[a];
        array [a]= array[b];
        array[b]=temp;
    }

}
