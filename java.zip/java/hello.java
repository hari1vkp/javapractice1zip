import java.util.Scanner;

/**
 * hello
 */
public class hello {

    public static void main(String[] args) {
        Scanner hari = new Scanner(System.in);
        String hai = hari.next();
        System.out.println(hai);
    }
}