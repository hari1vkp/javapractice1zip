import java.util.Scanner;
public class Hotel {
    public  static void main(String[]args) {
        Scanner a = new Scanner(System.in);
        String b=a.next();
        System.out.println("enga polam?");
        if (b.equals("kfc")){
            System.out.println("enna dishu nu sollu:");
            String dish=a.next();
            if(dish.equals("chicken")){
                System.out.println("drinks?");
                String drinks=a.next();
                if (drinks.equals("pepsi")){
                    System.out.println("ok done");
                }
                else {
                    System.out.println("vera drinks");
                }
            }
            else {
                System.out.println("vera dishu");
            }
        }
        else {
            System.out.println("vera hotel");
        }

    }
}
