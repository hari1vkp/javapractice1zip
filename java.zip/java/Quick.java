public class Quick
{
    public static void main(String[] args) {
        int[] array = {67, 90, 75, 68, 56};
        System.out.println("before");
        printarray(array);
        quicksort(array,0,array.length-1);
        System.out.println();
        System.out.println("after");
        printarray(array);
    }
    public static void printarray(int array[]) {
        for (int i = 0; i < array.length;i++)
        {
            System.out.print(array[i]+" ");
        }
    }

    public static void quicksort(int array[],int low,int high) {
        if (low>high)
        {
            return;
        }
        int pivot = array[high];
        int lp = low;
        int rp = high-1;
        while (lp <= rp) {
            while (lp <= rp && array[lp] < pivot) {
                lp++;
            }
            while (lp <= rp && array[rp] > pivot) {
                rp--;
            }
            if (lp <= rp) {
                swap(array,lp,rp);
                lp++;
                rp--;
            }
            swap(array,lp,high);
            quicksort(array,low,lp-1);
            quicksort(array,lp+1,high);
        }
    }
        public static void swap(int array[],int a,int b)
        {
            int temp=array[a];
            array[a]=array[b];
            array[b]=temp;

         }



}
