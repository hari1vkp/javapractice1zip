class Node{
    Node right,left;
    int key;
    public Node(int items){
        key=items;
        right=left=null;
    }
}
public class Binarytr {
    Node root;
    Binarytr(){
        root=null;
    }

    public static void main(String[] args) {
        Binarytr tree=new Binarytr();
        tree.root=new Node(1);
        tree.root.left=new Node(2);
        tree.root.right=new Node(3);
        tree.root.left.left=new Node(4);
        tree.root.left.right=new Node(5);
        System.out.println("inorder");
        tree.printInorder();


    }
    void printInorder(){
        printInorder(root);
    }
    void printInorder(Node node){
        if (node==null) {
            return;
            
        }
        printInorder(node.left);
        System.out.println(node.key+" ");
        printInorder(node.right);

    }

}