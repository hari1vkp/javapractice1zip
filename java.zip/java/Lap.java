public class Lap
{
 String name="username";
 String pro="intel/amd";
 int ram=8;
 int price=0;
    public static void main(String[] args) {
    Lap lap1=new Lap();
    System.out.println(lap1.name+lap1.ram+lap1.pro);
        Lap lap2= new Lap();
        lap2.name="hari";
        System.out.println(lap2);
    }

}

