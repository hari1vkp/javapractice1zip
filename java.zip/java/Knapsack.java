public class Knapsack {

    // Function to solve the knapsack problem using DP
    static int knapSack(int W, int wt[], int val[], int n) {
        int K[][] = new int[n + 1][W + 1];

        // Building the DP table in bottom-up manner
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= W; j++) {
                if (i == 0 || j == 0)
                    K[i][j] = 0;
                else if (wt[i - 1] <= j)
                    K[i][j] = Math.max(val[i - 1] + K[i - 1][j - wt[i - 1]], K[i - 1][j]);
                else
                    K[i][j] = K[i - 1][j];
            }
        }

        return K[n][W];
    }

    public static void main(String args[]) {
        int val[] = {60, 100, 120};
        int wt[] = {10, 20, 30};
        int W = 50;
        int n = val.length;

        System.out.println(knapSack(W, wt, val, n)); // Outputs 220
    }
}
/*
 * public class Knap {

    public static void main(String[] args) {
        int wt[]={40,100,110};
        int val[]={10,60,40};
        int n=val.length;
        int w=50;
        System.out.println(knap(wt,w,n,val));
    }
    public static int knap(int wt[],int w,int n,int val[])
    {
            int k[][]=new int[n+1][w+1];
            for (int i=0;i<=n;i++){
                for(int j=0;j<=w;j++){
                    if(i==0||j==0){
                        k[i][j]=0;
                    }
                    else if(wt[i-1]<=j){
                       // k[i][j]=Math.max(val[i-1]+k[i-1][j-wt[i-1]],k[i-1][j]);
                        k[i][j]=Math.max(val[i-1]+k[i-1][j-wt[i-1]],k[i-1][j]);
                    }
                    else{
                        k[i][j]=k[i-1][j];
                    }

                }
               
            }
        return k[n][w];
    }
}

 */

    
