public class MergeSort {
    static void mergesort(int arr[]){
        int len= arr.length;
        if(len<2){
            return;
        }
        int mid=len/2;
        int[] fh=new int[mid];
        int[] rh=new int[len-mid];


        for (int i=0;i<mid;i++){
            fh[i]=arr[i];
        }
        for(int i=mid;i<len;i++){
            rh[i-mid]=arr[i];
        }
        mergesort(fh);
        mergesort(rh);
        merge(arr,fh,rh);
    }
    static  void merge(int arr[],int ar1[],int ar2[]){
        int leftsize=ar1.length;
        int rightsize=ar2.length;
        int i=0,j=0,k=0;
        while (i<leftsize && j<rightsize)
        {
            if (ar1[i]<=ar2[j])
            {
                arr[k]=ar1[i];
                i++;
            }
            else {
                arr[k]=ar1[j];
                j++;
            }
            k++;
           /* while (i<leftsize){
                arr[k]=ar1[i];
                i++;
                k++;
            }
            while (j<rightsize){
                arr[k]=ar2[j];
                j++;
                k++;
            }

            */

        }


    }
    static void print(int[]arr){
        for (int i=0;i< arr.length;i++){
            System.out.println(arr[i]);
        }

    }

    public static void main(String[] args) {
        int[]arr={33,56,67,87,45,75,8,86};
        System.out.println("before");
        print(arr);
        mergesort(arr);
        System.out.println("after");
        print(arr);

    }

}