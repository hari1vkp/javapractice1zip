import java.util.Scanner;
public class School {
    String passorfail(int mark){
        String result=(mark>35?"pass":"fail");
        return result;
    }

    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        System.out.println("give mark");
        int mark= scan.nextInt();
        School rank=new School();
        String result= rank.passorfail(mark);
        System.out.println(result);

    }
}
