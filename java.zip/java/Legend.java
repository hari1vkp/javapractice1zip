public class Legend
{
    String wel(String a,String b){
        String name="hello iam "+a+" your ph no is "+b;
        return name;
    }

    public static void main(String[] args) {
        String name="hari";
        String num="123467890";
        Legend a=new Legend();
        String str=a.wel(name,num);
        System.out.println(str);
    }
}
