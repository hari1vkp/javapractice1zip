package practice;


import java.io.*;

public class Filehan {
    public static void main(String[] args) {
        try {
            FileWriter f1=new FileWriter("like.txt",true);

            BufferedWriter br=new BufferedWriter(f1);
            br.write("hello people");

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {


            FileReader fr = new FileReader("like.txt");

            BufferedReader br = new BufferedReader(fr);
            String line = br.readLine();
            System.out.println(line);
            br.close();


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
