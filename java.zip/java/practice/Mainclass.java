package practice;

class Person {
    public String name;
    protected int age;
    String add;
    private final int phno;

    Person(int phno, String name, int age, String add) {
        this.phno = phno;
        this.add = add;
        this.name = name;
        this.age = age;
        System.out.println(phno);
    }


}

class Emp extends Person {
    Emp(int phno, String name, int age, String add) {
        super(phno, name, age, add);
    }
}

public class Mainclass {
    public static void main(String[] args) {
        Emp em1 = new Emp(5656656, "hari", 21, "valikandapuram");
        System.out.println(em1.add);
        System.out.println(em1.name);
        System.out.println(em1.age);
    }


}
