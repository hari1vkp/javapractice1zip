package practice;

abstract class Vechile {
    static String getvech() {

        return "genric";
    }

    abstract void drive();

    final void start() {
        System.out.println("start eng");
    }
}

class Car extends Vechile {
    @Override
    void drive() {
        System.out.println("two weeler ,start just drive");
    }
}

class Bike extends Vechile {
    @Override
    void drive() {
        System.out.println("four weeler ,start just drive");
    }
}

public class Mainvech {
    public static void main(String[] args) {
        Bike b = new Bike();
        Car c = new Car();
        System.out.println(Vechile.getvech());
        b.drive();
        c.drive();
        b.start();
    }
}
