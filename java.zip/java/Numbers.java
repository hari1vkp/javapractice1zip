import java.util.Scanner;
public class Numbers {
    public static void main(String args[])
    {
        Scanner n=new Scanner(System.in);
        System.out.println("ent num:");
        int a=n.nextInt();
        System.out.println("ent num:");
        int b=n.nextInt();
        String res=a>b?"a is bigger":"b is bigger";
        System.out.println(res);

    }
}
