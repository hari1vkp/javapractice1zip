import java.util.Scanner;

public class Task1 {
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("enter a num1:");
        int a = scan.nextInt();
        System.out.println("enter a num2:");
        int b = scan.nextInt();
        int c = a + b;
        int d = a * b;
        int e = d / c;
        System.out.println("add of giv num:" + c);
        System.out.println("multiple of given num is:" + d);
        System.out.println("the multiply num div by added num:" + e);
        if(a%3==0&&a%5==0){
            System.out.println("the given value is dividable by 3&5");
        }
    }

}
