import java.util.Scanner;
public class Araayx {
    public static void main(String[]arg)
    {
        /* Scanner scan=new Scanner(System.in);
        int[]ar1=new int[5];
       // System.out.println("give a 5 num");
       //  ar1[0]=scan.nextInt();
        // ar1[1]=scan.nextInt();
         //ar1[2]=scan.nextInt();
         //ar1[3]=scan.nextInt();
         //ar1[4]=scan.nextInt();

       for (int i=0;i<5;i=i+1){
            System.out.println("give a num");
            ar1[i]= scan.nextInt();
        }
         int add=ar1[0]+ar1[1]+ ar1[2]+ar1[3]+ar1[04];
        System.out.println("the sum of an array is:"+add);*/
        for (int i=1;i<=10;i=i+1)
        {
            System.out.println(i+"*2="+(i*2));
        }
    }

}
