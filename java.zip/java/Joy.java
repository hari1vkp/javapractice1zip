import java.util.Scanner;
public class Joy {
    public static void main(String[]args){
        Scanner scan=new Scanner(System.in);
        System.out.println("no of ellement in arrar");
        int a= scan.nextInt();
        int[] arr=new int[a];
        for (int i=0;i<a;i=i+1){
            System.out.println("give values");
            arr[i]=scan.nextInt();
        }
        int b=a/2;
        System.out.println(arr[b]);
    }
}
