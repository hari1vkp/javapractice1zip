public class Star {
    public static void main(String arg[]){
        for (int i=0;i<3;i=i+1){

            for (int a=0;a<i+1;a=a+1){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
