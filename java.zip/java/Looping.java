public class Looping {
  public static void main(String args[]) {
      int coo=0;
    for(int i=1;i<=100;i=i+1)
    {
        if(i%3==0&&i%5==0){
            coo=coo+1;
            System.out.println("the NUM from 1 to 100 THAT DIV BY BOTH 3 AND 5 are :"+i);
        }

    }
      System.out.println("THE COUNT OF NUM ARE:"+coo);
  }
}
