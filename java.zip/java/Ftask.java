import java.util.Scanner;
public class Ftask {
    void joys()
    {
        System.out.println("enter your name");
        System.out.println("hello");
    }

    public static void main(String[] args) {
        Scanner hm = new Scanner(System.in);
        Ftask greet=new Ftask();
        greet.joys();
    }
}
